```python

```


```python
pip install opencv-python
```

    Requirement already satisfied: opencv-python in c:\users\user\anaconda3\lib\site-packages (4.5.4.60)
    Requirement already satisfied: numpy>=1.14.5 in c:\users\user\anaconda3\lib\site-packages (from opencv-python) (1.18.1)
    Note: you may need to restart the kernel to use updated packages.
    


```python
import cv2
```


```python
img=cv2.imread("rickky.jpg")
```


```python
cv2.imshow('image window', img)
cv2.waitKey(0)
cv2.destroyAllWindows()
```


```python
# Python program to explain cv2.imshow() method

# importing cv2
import cv2
from matplotlib import pyplot as plt

# path
path =  r'E:\chai\rickky.jpg'


# Reading an image in default mode
image = cv2.imread(path)

# Window name in which image is displayed
window_name = 'Image'

# Using cv2.imshow() method
# Displaying the image
image=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
plt.imshow( image)

#waits for user to press any key
#(this is necessary to avoid Python kernel form crashing)
cv2.waitKey()

#closing all open windows
cv2.destroyAllWindows()
```


![png](output_5_0.png)



```python
import cv2
from matplotlib import pyplot as plt
  
# create figure
fig = plt.figure(figsize=(10, 7))
  
# setting values to rows and column variables
rows = 2
columns = 2
  
# reading images
Image1 = cv2.imread('rickky.jpg')
Image2 = cv2.imread('brown.jpg')
Image3 = cv2.imread('rk.jpg')
Image4 = cv2.imread('blacky.jpg')
  
# Adds a subplot at the 1st position
fig.add_subplot(rows, columns, 1)
  
# showing image
plt.imshow(Image1)
plt.axis('off')
plt.title("First")
  
# Adds a subplot at the 2nd position
fig.add_subplot(rows, columns, 2)
  
# showing image
plt.imshow(Image2)
plt.axis('off')
plt.title("Second")
  
# Adds a subplot at the 3rd position
fig.add_subplot(rows, columns, 3)
  
# showing image
plt.imshow(Image3)
plt.axis('off')
plt.title("Third")
  
# Adds a subplot at the 4th position
fig.add_subplot(rows, columns, 4)
  
# showing image
plt.imshow(Image4)
plt.axis('off')
plt.title("Fourth")


```




    Text(0.5, 1.0, 'Fourth')




![png](output_6_1.png)



```python
import cv2
from matplotlib import pyplot as plt

img=cv2.imread('blacky.jpg',cv2.IMREAD_COLOR)

resized=cv2.resize(img,None,fx=1,fy=2,interpolation=cv2.INTER_CUBIC)

plt.imshow(img)
plt.imshow(resized)
cv2.waitKey()
cv2.destroyAllWindows()
```


![png](output_7_0.png)



```python
translation and rotation
```


```python
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
img = cv.imread('rk.jpg',0)
rows,cols = img.shape
M = np.float32([[1,0,100],[0,1,50]])
dst = cv.warpAffine(img,M,(cols,rows))
plt.imshow(dst)
cv.waitKey(0)
cv.destroyAllWindows()
```


![png](output_9_0.png)



```python
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
img = cv.imread('rk.jpg',0)
rows,cols = img.shape
M = np.float32([[1,0,100],[0,1,50]])
dst = cv.warpAffine(img,M,(cols,rows))
img = cv.imread('rk.jpg',0)
rows,cols = img.shape
# cols-1 and rows-1 are the coordinate limits.
M = cv.getRotationMatrix2D(((cols-1)/2.0,(rows-1)/2.0),90,1)
dst = cv.warpAffine(img,M,(cols,rows))
plt.imshow(dst)
cv.waitKey(0)
cv.destroyAllWindows()
```


![png](output_10_0.png)



```python
affine transformation
```


```python
import numpy as np
import cv2 as cv
img = cv.imread('blacky.jpg')
rows,cols,ch = img.shape
pts1 = np.float32([[50,50],[200,50],[50,200]])
pts2 = np.float32([[10,100],[200,50],[100,250]])
M = cv.getAffineTransform(pts1,pts2)
dst = cv.warpAffine(img,M,(cols,rows))
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


![png](output_12_0.png)



```python
img = cv.imread('rk.jpg')
rows,cols,ch = img.shape
pts1 = np.float32([[56,65],[368,52],[28,387],[389,390]])
pts2 = np.float32([[0,0],[300,0],[0,300],[300,300]])
M = cv.getPerspectiveTransform(pts1,pts2)
dst = cv.warpPerspective(img,M,(300,300))
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


![png](output_13_0.png)



```python
text = "Chaithra"

for character in text:
    print(character)
```

    C
    h
    a
    i
    t
    h
    r
    a
    


```python
languages = ["Chaithra", "Varshini", "Rksha"]

for language in languages:
    print(language)
```

    Chaithra
    Varshini
    Rksha
    


```python
list=[1,2,3,4,5,6,7,8,9,10]
n=5
for i in list:
    if i%2==0:
        c=n*i
        print(c)
        print("Multiples of 5")
```

    10
    Multiples of 5
    20
    Multiples of 5
    30
    Multiples of 5
    40
    Multiples of 5
    50
    Multiples of 5
    


```python
print("Enter Marks Obtained in 5 Subjects: ")
markOne = int(input())
markTwo = int(input())
markThree = int(input())
markFour = int(input())
markFive = int(input())

tot = markOne+markTwo+markThree+markFour+markFive
avg = tot/5

if avg>=90 and avg<=100:
    print("Your Grade is A+")
elif avg>=71 and avg<89:
    print("Your Grade is A")
elif avg>=60 and avg<70:
    print("Your Grade is B+")
elif avg>=46 and avg<60:
    print("Your Grade is B")
elif avg>=36 and avg<45:
    print("Your Grade is C+")
elif avg>=0 and avg<35:
    print("Your Grade is C")
else:
    print("Invalid Input!")
```

    Enter Marks Obtained in 5 Subjects: 
    60
    70
    60
    70
    60
    Your Grade is B+
    


```python
weeks=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']

for x in weeks:
    if x=='Sunday':
     print('Holiday')
     continue
    if x=='Monday':
     print('No Harish sir class in Monday')   
     continue
    if x=='Tuesday':
     print('No Harish sir class in Tuesday')   
     continue
    if x=='Saturday':
     print('No Harish sir class in Saturday')   
     continue
    print(x)
```

    No Harish sir class in Monday
    No Harish sir class in Tuesday
    Wednesday
    Thursday
    Friday
    No Harish sir class in Saturday
    Holiday
    


```python

```

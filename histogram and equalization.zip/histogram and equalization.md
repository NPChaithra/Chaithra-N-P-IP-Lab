```python
import cv2
# import Numpy
import numpy as np
# reading an image using imreadmethod
my_img = cv2.imread('blacky.jpg', 0)
equ = cv2.equalizeHist(my_img)
# stacking both the images side-by-side orientation
res = np.hstack((my_img, equ))
# showing image input vs output
cv2.imshow('image', res)
cv2.waitKey(0)
cv2.destroyAllWindows()
```


```python
import cv2
# import Numpy
import numpy as np
from matplotlib import pyplot as plt
# reading an image using imreadmethod
my_img = cv2.imread('brown.jpg', 0)
equ = cv2.equalizeHist(my_img)
# stacking both the images side-by-side orientation
res = np.hstack((my_img, equ))
# showing image input vs output
cv2.imshow('image', res)
cv2.waitKey(0)
cv2.destroyAllWindows()
hist,bins = np.histogram(equ.flatten(),256,[0,256])
cdf = hist.cumsum()
cdf_normalized = cdf * float(hist.max()) / cdf.max()
plt.plot(cdf_normalized, color = 'b')
plt.hist(equ.flatten(),256,[0,256], color = 'r')
plt.xlim([0,256])
plt.legend(('cdf','histogram'), loc = 'upper left')
plt.show()
```


![png](output_1_0.png)



```python
from PIL import Image

```


```python
image=Image.open('blacky.jpg')
```


```python
r,g,b=image.split()
```


```python
len(g.histogram())
```




    256




```python
g.histogram()
```




    [36,
     28,
     50,
     98,
     159,
     222,
     184,
     199,
     187,
     183,
     163,
     191,
     184,
     190,
     195,
     224,
     222,
     278,
     314,
     315,
     399,
     475,
     485,
     539,
     597,
     616,
     596,
     632,
     701,
     788,
     872,
     823,
     830,
     863,
     835,
     832,
     932,
     984,
     1027,
     1089,
     1121,
     1280,
     1205,
     1361,
     1457,
     1521,
     1608,
     1647,
     1713,
     1582,
     1586,
     1590,
     1595,
     1575,
     1540,
     1546,
     1521,
     1465,
     1525,
     1539,
     1547,
     1513,
     1428,
     1517,
     1553,
     1588,
     1532,
     1552,
     1554,
     1544,
     1543,
     1579,
     1606,
     1621,
     1582,
     1695,
     1775,
     1740,
     1771,
     1798,
     1894,
     1924,
     1984,
     1992,
     2113,
     2228,
     2367,
     2432,
     2525,
     2594,
     2918,
     2950,
     3178,
     3290,
     3467,
     3718,
     3725,
     3920,
     4097,
     4214,
     4366,
     4421,
     4683,
     4838,
     4982,
     5134,
     5335,
     5508,
     5618,
     5802,
     5835,
     5976,
     6109,
     6238,
     6500,
     6662,
     6659,
     6773,
     6946,
     7076,
     7128,
     7315,
     7355,
     7442,
     7482,
     7847,
     7669,
     7646,
     7931,
     7692,
     7855,
     7738,
     7846,
     7991,
     7801,
     7855,
     7947,
     7554,
     7550,
     7718,
     7761,
     7720,
     7551,
     7765,
     7578,
     7660,
     7516,
     7544,
     7509,
     7690,
     7798,
     7680,
     7580,
     7802,
     7774,
     7936,
     8168,
     8077,
     8282,
     8274,
     8381,
     8408,
     8687,
     8712,
     8992,
     8895,
     9250,
     9062,
     9069,
     9258,
     9149,
     9243,
     9313,
     9396,
     9417,
     9399,
     9557,
     9154,
     9314,
     9261,
     9090,
     8768,
     8559,
     8210,
     7940,
     7536,
     7195,
     6859,
     6486,
     6157,
     5747,
     5514,
     5206,
     4833,
     4650,
     4212,
     3987,
     3723,
     3447,
     3221,
     2842,
     2716,
     2443,
     2245,
     2186,
     1869,
     1758,
     1717,
     1542,
     1403,
     1324,
     1229,
     1072,
     980,
     888,
     899,
     797,
     692,
     665,
     629,
     555,
     522,
     479,
     448,
     431,
     389,
     368,
     369,
     330,
     329,
     311,
     322,
     310,
     313,
     318,
     332,
     304,
     304,
     347,
     305,
     322,
     341,
     380,
     363,
     387,
     406,
     413,
     479,
     463,
     555,
     659,
     742,
     1010,
     1763,
     5797,
     522811]




```python
width, height = image.size
print(width,height)
```

    1200 1200
    


```python
import cv2 as cv
img=cv.imread('blacky.jpg')
print(img)
```

    [[[ 69 105 193]
      [ 64 104 193]
      [ 58 102 193]
      ...
      [ 16  50  80]
      [ 18  52  82]
      [ 19  53  83]]
    
     [[ 72 109 193]
      [ 68 108 191]
      [ 65 106 191]
      ...
      [ 15  49  79]
      [ 16  50  80]
      [ 17  51  81]]
    
     [[ 79 116 190]
      [ 75 114 189]
      [ 74 113 188]
      ...
      [ 14  45  76]
      [ 16  47  78]
      [ 17  48  79]]
    
     ...
    
     [[ 27 116 196]
      [ 29 119 196]
      [ 32 122 199]
      ...
      [ 34 130 190]
      [ 34 130 190]
      [ 35 131 191]]
    
     [[ 32 122 199]
      [ 32 122 199]
      [ 33 124 199]
      ...
      [ 34 130 190]
      [ 34 130 190]
      [ 35 131 191]]
    
     [[ 34 125 200]
      [ 33 124 199]
      [ 31 123 196]
      ...
      [ 34 130 190]
      [ 34 130 190]
      [ 35 131 191]]]
    


```python

```


```python

```
